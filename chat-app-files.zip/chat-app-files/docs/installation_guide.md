# دليل التثبيت والإعداد لتطبيق المراسلة

## متطلبات النظام

- Node.js الإصدار 18.0.0 أو أحدث
- npm الإصدار 8.0.0 أو أحدث
- حساب على Cloudflare (للنشر)

## تثبيت التطبيق محلياً

### 1. استنساخ المشروع

```bash
git clone https://github.com/yourusername/chat-app.git
cd chat-app
```

### 2. تثبيت التبعيات

```bash
npm install
```

### 3. إعداد المتغيرات البيئية

قم بإنشاء ملف `.env.local` في المجلد الرئيسي للمشروع وأضف المتغيرات التالية:

```
JWT_SECRET=your_jwt_secret_key
```

### 4. إعداد قاعدة البيانات المحلية

```bash
# تطبيق ملف الترحيل الأولي
wrangler d1 execute DB --local --file=migrations/0001_initial.sql

# تطبيق ملف الترحيل للإنتاج (اختياري للبيئة المحلية)
wrangler d1 execute DB --local --file=migrations/0002_production_setup.sql
```

### 5. تشغيل التطبيق في وضع التطوير

```bash
npm run dev
```

بعد تنفيذ هذا الأمر، سيكون التطبيق متاحاً على العنوان المحلي: `http://localhost:3000`

## نشر التطبيق على Cloudflare Pages

### 1. إعداد حساب Cloudflare

- قم بإنشاء حساب على [Cloudflare](https://dash.cloudflare.com/sign-up)
- قم بتثبيت أداة Wrangler CLI:
  ```bash
  npm install -g wrangler
  ```
- قم بتسجيل الدخول إلى Wrangler:
  ```bash
  wrangler login
  ```

### 2. إعداد قاعدة بيانات D1

```bash
# إنشاء قاعدة بيانات D1 جديدة
wrangler d1 create chat_app_db

# تطبيق ملفات الترحيل على قاعدة البيانات
wrangler d1 execute chat_app_db --file=migrations/0001_initial.sql
wrangler d1 execute chat_app_db --file=migrations/0002_production_setup.sql
```

### 3. تعديل ملف التكوين للإنتاج

قم بتعديل ملف `wrangler.production.toml` وتحديث معرف قاعدة البيانات بالمعرف الذي حصلت عليه من الخطوة السابقة:

```toml
[[d1_databases]]
binding = "DB"
database_name = "chat_app_db"
database_id = "معرف_قاعدة_البيانات_الخاصة_بك"
```

### 4. بناء التطبيق للإنتاج

```bash
# نسخ ملف التكوين للإنتاج
cp next.config.production.js next.config.js
cp wrangler.production.toml wrangler.toml

# بناء التطبيق
npm run build
```

### 5. نشر التطبيق

```bash
# نشر التطبيق على Cloudflare Pages
wrangler pages deploy .next
```

بعد اكتمال عملية النشر، ستحصل على رابط للتطبيق المنشور على نطاق Cloudflare Pages.

## تكوين المتغيرات البيئية في Cloudflare Pages

بعد نشر التطبيق، يجب تكوين المتغيرات البيئية في لوحة تحكم Cloudflare Pages:

1. انتقل إلى لوحة تحكم Cloudflare Pages
2. اختر مشروعك
3. انتقل إلى تبويب "Settings" ثم "Environment variables"
4. أضف المتغيرات التالية:
   - `JWT_SECRET`: مفتاح سري قوي لتوقيع JWT
   - `ENVIRONMENT`: اضبطه على "production"

## تحديث التطبيق

لتحديث التطبيق بعد إجراء تغييرات:

1. قم بتنفيذ التغييرات المطلوبة
2. اختبر التغييرات محلياً
3. قم ببناء التطبيق للإنتاج
4. أعد نشر التطبيق باستخدام الأمر `wrangler pages deploy .next`

## استكشاف الأخطاء وإصلاحها

### مشاكل في التثبيت المحلي

- **خطأ في تثبيت التبعيات**: حاول حذف مجلد `node_modules` وملف `package-lock.json` ثم أعد تنفيذ `npm install`
- **خطأ في تشغيل التطبيق**: تأكد من تثبيت جميع التبعيات وإعداد المتغيرات البيئية بشكل صحيح

### مشاكل في النشر

- **خطأ في النشر**: تأكد من تسجيل الدخول إلى Wrangler وأن لديك الصلاحيات المناسبة
- **مشاكل في قاعدة البيانات**: تأكد من إنشاء قاعدة البيانات وتطبيق ملفات الترحيل بشكل صحيح
- **مشاكل في المتغيرات البيئية**: تأكد من تكوين المتغيرات البيئية في لوحة تحكم Cloudflare Pages

## الدعم الفني

إذا واجهتك أي مشكلة في التثبيت أو النشر، يرجى التواصل مع فريق الدعم الفني عبر البريد الإلكتروني: support@chatapp.com
