// تكوين Next.js للإنتاج
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  images: {
    domains: ['cloudflare-assets.com'],
    formats: ['image/avif', 'image/webp'],
  },
  compiler: {
    removeConsole: process.env.NODE_ENV === 'production',
  },
  experimental: {
    optimizeCss: true,
    scrollRestoration: true,
  },
  // تحسينات الأداء
  poweredByHeader: false,
  compress: true,
  productionBrowserSourceMaps: false,
  // تكوين Cloudflare Pages
  output: 'standalone',
};

export default nextConfig;
