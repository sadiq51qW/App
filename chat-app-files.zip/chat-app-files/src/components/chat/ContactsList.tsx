'use client';

import { useState, useEffect } from 'react';

interface Contact {
  id: number;
  username: string;
  full_name: string;
  profile_picture?: string;
  status: string;
  last_seen?: string;
}

export default function ContactsList({ onSelectContact }: { onSelectContact: (contact: Contact) => void }) {
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const fetchContacts = async () => {
      try {
        const token = localStorage.getItem('token');
        if (!token) return;

        const response = await fetch('/api/contacts', {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        if (!response.ok) {
          throw new Error('فشل في جلب جهات الاتصال');
        }

        const data = await response.json();
        setContacts(data.contacts);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchContacts();
  }, []);

  const filteredContacts = contacts.filter(contact => 
    contact.full_name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    contact.username.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-blue-500 border-t-transparent"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 text-center text-red-500">
        {error}
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col">
      <div className="p-3">
        <input
          type="text"
          placeholder="البحث عن جهات الاتصال..."
          className="w-full rounded-lg border border-gray-300 p-2 focus:border-blue-500 focus:outline-none"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>
      
      <div className="flex-1 overflow-y-auto">
        {filteredContacts.length === 0 ? (
          <div className="p-4 text-center text-gray-500">
            لا توجد جهات اتصال
          </div>
        ) : (
          <ul className="divide-y divide-gray-200">
            {filteredContacts.map((contact) => (
              <li 
                key={contact.id}
                className="cursor-pointer hover:bg-gray-50"
                onClick={() => onSelectContact(contact)}
              >
                <div className="flex items-center p-3">
                  <div className="relative h-10 w-10 flex-shrink-0">
                    {contact.profile_picture ? (
                      <img
                        src={contact.profile_picture}
                        alt={contact.full_name}
                        className="h-full w-full rounded-full object-cover"
                      />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center rounded-full bg-blue-100 text-blue-500">
                        {contact.full_name.charAt(0).toUpperCase()}
                      </div>
                    )}
                    <span className={`absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-white ${
                      contact.status === 'online' ? 'bg-green-500' : 'bg-gray-300'
                    }`}></span>
                  </div>
                  <div className="mr-3 flex-1">
                    <div className="font-medium text-gray-800">{contact.full_name}</div>
                    <div className="text-sm text-gray-500">
                      {contact.status === 'online' ? 'متصل الآن' : 'غير متصل'}
                    </div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
