'use client';

import { useState, useEffect, useRef } from 'react';
import useRealTimeService from '@/hooks/useRealTimeService';

interface Message {
  id: number;
  sender_id: number;
  content: string;
  is_read: boolean;
  created_at: string;
  sender_name?: string;
}

interface ChatWindowProps {
  conversationId: number | null;
  currentUserId: number;
  contactName: string;
}

export default function ChatWindow({ conversationId, currentUserId, contactName }: ChatWindowProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [isContactTyping, setIsContactTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // استخدام خدمة الوقت الحقيقي
  const { isConnected, sendTypingIndicator } = useRealTimeService({
    conversationId,
    userId: currentUserId,
    onNewMessage: (message) => {
      setMessages(prev => [...prev, message]);
    },
    onStatusChange: (userId, status) => {
      // يمكن استخدام هذا لتحديث حالة جهة الاتصال
      console.log(`تغيرت حالة المستخدم ${userId} إلى ${status}`);
    },
    onTypingIndicator: (userId, isTyping) => {
      if (userId !== currentUserId) {
        setIsContactTyping(isTyping);
      }
    }
  });

  // جلب الرسائل عند تغيير المحادثة
  useEffect(() => {
    if (!conversationId) return;
    
    const fetchMessages = async () => {
      try {
        setLoading(true);
        const token = localStorage.getItem('token');
        if (!token) return;

        const response = await fetch(`/api/conversations/${conversationId}/messages`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        if (!response.ok) {
          throw new Error('فشل في جلب الرسائل');
        }

        const data = await response.json();
        setMessages(data.messages);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchMessages();
  }, [conversationId]);

  // التمرير إلى آخر رسالة عند تحديث الرسائل
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // إرسال مؤشر الكتابة عند كتابة رسالة جديدة
  const handleMessageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setNewMessage(e.target.value);
    
    if (conversationId) {
      // إلغاء المؤقت السابق إذا كان موجودًا
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
      
      // إرسال مؤشر الكتابة (نشط)
      sendTypingIndicator(true);
      
      // إعداد مؤقت لإرسال مؤشر الكتابة (غير نشط) بعد توقف الكتابة
      typingTimeoutRef.current = setTimeout(() => {
        sendTypingIndicator(false);
      }, 2000);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !conversationId) return;

    try {
      const token = localStorage.getItem('token');
      if (!token) return;

      // إرسال مؤشر الكتابة (غير نشط)
      sendTypingIndicator(false);
      
      // إلغاء المؤقت إذا كان موجودًا
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
        typingTimeoutRef.current = null;
      }

      const response = await fetch(`/api/conversations/${conversationId}/messages`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          content: newMessage,
        }),
      });

      if (!response.ok) {
        throw new Error('فشل في إرسال الرسالة');
      }

      const data = await response.json();
      
      // إضافة الرسالة الجديدة إلى القائمة
      setMessages(prev => [...prev, data.message]);
      
      // مسح حقل الإدخال
      setNewMessage('');
    } catch (err: any) {
      setError(err.message);
    }
  };

  if (!conversationId) {
    return (
      <div className="flex h-full flex-col items-center justify-center bg-gray-50 p-4">
        <div className="text-center text-gray-500">
          <div className="mb-4 text-5xl">💬</div>
          <h3 className="mb-2 text-xl font-medium">اختر محادثة للبدء</h3>
          <p>حدد جهة اتصال من القائمة لبدء المحادثة</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col">
      {/* رأس المحادثة */}
      <div className="border-b border-gray-200 bg-white p-3 shadow-sm">
        <div className="flex items-center">
          <div className="mr-3">
            <div className="text-lg font-medium">{contactName}</div>
            {isConnected && (
              <div className="text-xs text-green-500">متصل بخدمة الوقت الحقيقي</div>
            )}
          </div>
        </div>
      </div>

      {/* منطقة الرسائل */}
      <div className="flex-1 overflow-y-auto bg-gray-50 p-4">
        {loading ? (
          <div className="flex h-full items-center justify-center">
            <div className="h-8 w-8 animate-spin rounded-full border-4 border-blue-500 border-t-transparent"></div>
          </div>
        ) : error ? (
          <div className="p-4 text-center text-red-500">
            {error}
          </div>
        ) : messages.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center text-center text-gray-500">
            <div className="mb-2 text-3xl">👋</div>
            <p>لا توجد رسائل بعد. ابدأ المحادثة الآن!</p>
          </div>
        ) : (
          <div className="space-y-3">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.sender_id === currentUserId ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[70%] rounded-lg p-3 ${
                    message.sender_id === currentUserId
                      ? 'bg-blue-500 text-white'
                      : 'bg-white text-gray-800'
                  }`}
                >
                  <div className="text-sm">{message.content}</div>
                  <div className={`mt-1 text-right text-xs ${
                    message.sender_id === currentUserId ? 'text-blue-100' : 'text-gray-500'
                  }`}>
                    {new Date(message.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
              </div>
            ))}
            {isContactTyping && (
              <div className="flex justify-start">
                <div className="rounded-lg bg-gray-100 p-3">
                  <div className="flex space-x-1 space-x-reverse">
                    <div className="h-2 w-2 animate-bounce rounded-full bg-gray-400"></div>
                    <div className="h-2 w-2 animate-bounce rounded-full bg-gray-400" style={{ animationDelay: '0.2s' }}></div>
                    <div className="h-2 w-2 animate-bounce rounded-full bg-gray-400" style={{ animationDelay: '0.4s' }}></div>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* منطقة إدخال الرسالة */}
      <div className="border-t border-gray-200 bg-white p-3">
        <form onSubmit={handleSendMessage} className="flex">
          <input
            type="text"
            placeholder="اكتب رسالة..."
            className="flex-1 rounded-l-lg border border-gray-300 p-2 focus:border-blue-500 focus:outline-none"
            value={newMessage}
            onChange={handleMessageChange}
          />
          <button
            type="submit"
            disabled={!newMessage.trim()}
            className="rounded-r-lg bg-blue-500 px-4 py-2 text-white hover:bg-blue-600 focus:outline-none disabled:opacity-50"
          >
            إرسال
          </button>
        </form>
      </div>
    </div>
  );
}
