'use client';

import { useEffect, useState } from 'react';

interface RealTimeServiceProps {
  conversationId: number | null;
  userId: number;
  onNewMessage: (message: any) => void;
  onStatusChange: (userId: number, status: string) => void;
  onTypingIndicator: (userId: number, isTyping: boolean) => void;
}

export default function useRealTimeService({
  conversationId,
  userId,
  onNewMessage,
  onStatusChange,
  onTypingIndicator
}: RealTimeServiceProps) {
  const [eventSource, setEventSource] = useState<EventSource | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // إنشاء اتصال SSE عند تحميل المكون
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) return;

    // إغلاق الاتصال السابق إذا كان موجودًا
    if (eventSource) {
      eventSource.close();
    }

    // إنشاء اتصال SSE جديد
    const newEventSource = new EventSource(`/api/realtime?token=${token}`);

    newEventSource.onopen = () => {
      setIsConnected(true);
      setError(null);
      console.log('تم فتح اتصال SSE');
    };

    newEventSource.onerror = (err) => {
      setIsConnected(false);
      setError('حدث خطأ في اتصال الوقت الحقيقي');
      console.error('خطأ في اتصال SSE:', err);
      newEventSource.close();
    };

    // الاستماع لأحداث الرسائل الجديدة
    newEventSource.addEventListener('new_message', (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.conversation_id === conversationId) {
          onNewMessage(data.message);
        }
      } catch (err) {
        console.error('خطأ في معالجة حدث الرسالة الجديدة:', err);
      }
    });

    // الاستماع لأحداث تغيير الحالة
    newEventSource.addEventListener('status_change', (event) => {
      try {
        const data = JSON.parse(event.data);
        onStatusChange(data.user_id, data.status);
      } catch (err) {
        console.error('خطأ في معالجة حدث تغيير الحالة:', err);
      }
    });

    // الاستماع لأحداث مؤشر الكتابة
    newEventSource.addEventListener('typing_indicator', (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.conversation_id === conversationId) {
          onTypingIndicator(data.user_id, data.is_typing);
        }
      } catch (err) {
        console.error('خطأ في معالجة حدث مؤشر الكتابة:', err);
      }
    });

    setEventSource(newEventSource);

    // تنظيف الاتصال عند إلغاء تحميل المكون
    return () => {
      newEventSource.close();
    };
  }, [conversationId, userId, onNewMessage, onStatusChange, onTypingIndicator]);

  // دالة لإرسال مؤشر الكتابة
  const sendTypingIndicator = async (isTyping: boolean) => {
    if (!conversationId) return;

    try {
      const token = localStorage.getItem('token');
      if (!token) return;

      await fetch(`/api/realtime/typing`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          conversation_id: conversationId,
          is_typing: isTyping
        }),
      });
    } catch (err) {
      console.error('خطأ في إرسال مؤشر الكتابة:', err);
    }
  };

  return {
    isConnected,
    error,
    sendTypingIndicator
  };
}
