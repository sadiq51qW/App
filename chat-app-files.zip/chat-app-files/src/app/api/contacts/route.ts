import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import jwt from 'jsonwebtoken';

// المفتاح السري لتوقيع JWT
const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret_key';

// التحقق من التوكن
const verifyToken = (request: NextRequest) => {
  const authHeader = request.headers.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }

  const token = authHeader.split(' ')[1];
  try {
    return jwt.verify(token, JWT_SECRET) as { id: number };
  } catch (error) {
    return null;
  }
};

// جلب جهات الاتصال للمستخدم الحالي
export async function GET(request: NextRequest, { env }: { env: { DB: D1Database } }) {
  try {
    // التحقق من المستخدم
    const decoded = verifyToken(request);
    if (!decoded) {
      return NextResponse.json(
        { error: 'غير مصرح' },
        { status: 401 }
      );
    }

    // جلب جميع المستخدمين باستثناء المستخدم الحالي (كمثال بسيط)
    // في التطبيق الحقيقي، يجب جلب جهات الاتصال المضافة فقط
    const users = await env.DB.prepare(
      'SELECT id, username, full_name, profile_picture, status, last_seen FROM users WHERE id != ?'
    )
      .bind(decoded.id)
      .all();

    return NextResponse.json({
      contacts: users.results
    });
  } catch (error) {
    console.error('خطأ في جلب جهات الاتصال:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في الخادم' },
      { status: 500 }
    );
  }
}
