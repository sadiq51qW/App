import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import jwt from 'jsonwebtoken';

// المفتاح السري لتوقيع JWT
const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret_key';

// التحقق من التوكن
const verifyToken = (token: string) => {
  try {
    return jwt.verify(token, JWT_SECRET) as { id: number };
  } catch (error) {
    return null;
  }
};

// واجهة API للتواصل في الوقت الحقيقي باستخدام Server-Sent Events
export async function GET(request: NextRequest, { env }: { env: { DB: D1Database } }) {
  // استخراج التوكن من معلمات الاستعلام
  const url = new URL(request.url);
  const token = url.searchParams.get('token');

  if (!token) {
    return NextResponse.json(
      { error: 'غير مصرح' },
      { status: 401 }
    );
  }

  // التحقق من صحة التوكن
  const decoded = verifyToken(token);
  if (!decoded) {
    return NextResponse.json(
      { error: 'غير مصرح' },
      { status: 401 }
    );
  }

  // تحديث حالة المستخدم إلى متصل
  await env.DB.prepare(
    'UPDATE users SET status = ?, last_seen = CURRENT_TIMESTAMP WHERE id = ?'
  )
    .bind('online', decoded.id)
    .run();

  // إنشاء استجابة SSE
  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    start(controller) {
      // إرسال حدث للاتصال
      controller.enqueue(encoder.encode('event: connection\ndata: {"connected": true}\n\n'));

      // إعداد مؤقت لإرسال نبضات للحفاظ على الاتصال
      const heartbeat = setInterval(() => {
        controller.enqueue(encoder.encode(': heartbeat\n\n'));
      }, 30000);

      // تنظيف عند إغلاق الاتصال
      request.signal.addEventListener('abort', () => {
        clearInterval(heartbeat);
        controller.close();
      });
    }
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive'
    }
  });
}
