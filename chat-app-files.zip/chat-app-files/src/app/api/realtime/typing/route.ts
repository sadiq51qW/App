import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import jwt from 'jsonwebtoken';

// المفتاح السري لتوقيع JWT
const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret_key';

// التحقق من التوكن
const verifyToken = (request: NextRequest) => {
  const authHeader = request.headers.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }

  const token = authHeader.split(' ')[1];
  try {
    return jwt.verify(token, JWT_SECRET) as { id: number };
  } catch (error) {
    return null;
  }
};

// واجهة API لإرسال مؤشر الكتابة
export async function POST(request: NextRequest, { env }: { env: { DB: D1Database } }) {
  try {
    // التحقق من المستخدم
    const decoded = verifyToken(request);
    if (!decoded) {
      return NextResponse.json(
        { error: 'غير مصرح' },
        { status: 401 }
      );
    }

    const { conversation_id, is_typing } = await request.json();

    if (!conversation_id) {
      return NextResponse.json(
        { error: 'معرف المحادثة مطلوب' },
        { status: 400 }
      );
    }

    // التحقق من أن المستخدم مشارك في المحادثة
    const participant = await env.DB.prepare(
      'SELECT * FROM conversation_participants WHERE conversation_id = ? AND user_id = ?'
    )
      .bind(conversation_id, decoded.id)
      .first();

    if (!participant) {
      return NextResponse.json(
        { error: 'غير مصرح للوصول إلى هذه المحادثة' },
        { status: 403 }
      );
    }

    // في تطبيق حقيقي، هنا سنقوم بإرسال حدث إلى جميع المستخدمين المتصلين في المحادثة
    // باستخدام خدمة مثل Cloudflare Durable Objects أو قناة WebSockets

    return NextResponse.json({
      success: true,
      message: 'تم إرسال مؤشر الكتابة بنجاح'
    });
  } catch (error) {
    console.error('خطأ في إرسال مؤشر الكتابة:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في الخادم' },
      { status: 500 }
    );
  }
}
