import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import jwt from 'jsonwebtoken';

// المفتاح السري لتوقيع JWT
const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret_key';

// التحقق من التوكن
const verifyToken = (request: NextRequest) => {
  const authHeader = request.headers.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }

  const token = authHeader.split(' ')[1];
  try {
    return jwt.verify(token, JWT_SECRET) as { id: number };
  } catch (error) {
    return null;
  }
};

// إنشاء محادثة جديدة
export async function POST(request: NextRequest, { env }: { env: { DB: D1Database } }) {
  try {
    // التحقق من المستخدم
    const decoded = verifyToken(request);
    if (!decoded) {
      return NextResponse.json(
        { error: 'غير مصرح' },
        { status: 401 }
      );
    }

    const { contact_id, type = 'private' } = await request.json();

    if (!contact_id) {
      return NextResponse.json(
        { error: 'معرف جهة الاتصال مطلوب' },
        { status: 400 }
      );
    }

    // التحقق من وجود محادثة سابقة بين المستخدمين (للمحادثات الخاصة)
    if (type === 'private') {
      const existingConversation = await env.DB.prepare(`
        SELECT c.id FROM conversations c
        JOIN conversation_participants p1 ON c.id = p1.conversation_id
        JOIN conversation_participants p2 ON c.id = p2.conversation_id
        WHERE c.type = 'private'
        AND p1.user_id = ?
        AND p2.user_id = ?
      `)
        .bind(decoded.id, contact_id)
        .first();

      if (existingConversation) {
        return NextResponse.json({
          conversation_id: existingConversation.id,
          message: 'المحادثة موجودة بالفعل'
        });
      }
    }

    // إنشاء محادثة جديدة
    const result = await env.DB.prepare(
      'INSERT INTO conversations (name, type, created_by) VALUES (?, ?, ?) RETURNING id'
    )
      .bind(null, type, decoded.id)
      .first();

    if (!result) {
      return NextResponse.json(
        { error: 'فشل في إنشاء المحادثة' },
        { status: 500 }
      );
    }

    const conversationId = result.id;

    // إضافة المستخدم الحالي كمشارك
    await env.DB.prepare(
      'INSERT INTO conversation_participants (conversation_id, user_id) VALUES (?, ?)'
    )
      .bind(conversationId, decoded.id)
      .run();

    // إضافة جهة الاتصال كمشارك
    await env.DB.prepare(
      'INSERT INTO conversation_participants (conversation_id, user_id) VALUES (?, ?)'
    )
      .bind(conversationId, contact_id)
      .run();

    return NextResponse.json({
      conversation_id: conversationId,
      message: 'تم إنشاء المحادثة بنجاح'
    });
  } catch (error) {
    console.error('خطأ في إنشاء المحادثة:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في الخادم' },
      { status: 500 }
    );
  }
}

// جلب جميع محادثات المستخدم
export async function GET(request: NextRequest, { env }: { env: { DB: D1Database } }) {
  try {
    // التحقق من المستخدم
    const decoded = verifyToken(request);
    if (!decoded) {
      return NextResponse.json(
        { error: 'غير مصرح' },
        { status: 401 }
      );
    }

    // جلب المحادثات مع آخر رسالة وبيانات المشاركين
    const conversations = await env.DB.prepare(`
      SELECT 
        c.id, 
        c.type, 
        c.created_at,
        c.updated_at,
        CASE 
          WHEN c.type = 'private' THEN (
            SELECT u.full_name 
            FROM users u
            JOIN conversation_participants cp ON u.id = cp.user_id
            WHERE cp.conversation_id = c.id AND u.id != ?
            LIMIT 1
          )
          ELSE c.name
        END as name,
        (
          SELECT m.content
          FROM messages m
          WHERE m.conversation_id = c.id
          ORDER BY m.created_at DESC
          LIMIT 1
        ) as last_message,
        (
          SELECT m.created_at
          FROM messages m
          WHERE m.conversation_id = c.id
          ORDER BY m.created_at DESC
          LIMIT 1
        ) as last_message_time,
        (
          SELECT COUNT(*)
          FROM messages m
          WHERE m.conversation_id = c.id
          AND m.is_read = 0
          AND m.sender_id != ?
        ) as unread_count
      FROM conversations c
      JOIN conversation_participants cp ON c.id = cp.conversation_id
      WHERE cp.user_id = ?
      ORDER BY last_message_time DESC NULLS LAST
    `)
      .bind(decoded.id, decoded.id, decoded.id)
      .all();

    return NextResponse.json({
      conversations: conversations.results
    });
  } catch (error) {
    console.error('خطأ في جلب المحادثات:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في الخادم' },
      { status: 500 }
    );
  }
}
