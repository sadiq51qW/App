import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import jwt from 'jsonwebtoken';

// المفتاح السري لتوقيع JWT
const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret_key';

// التحقق من التوكن
const verifyToken = (request: NextRequest) => {
  const authHeader = request.headers.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }

  const token = authHeader.split(' ')[1];
  try {
    return jwt.verify(token, JWT_SECRET) as { id: number };
  } catch (error) {
    return null;
  }
};

// جلب رسائل محادثة معينة
export async function GET(
  request: NextRequest,
  { params, env }: { params: { id: string }, env: { DB: D1Database } }
) {
  try {
    // التحقق من المستخدم
    const decoded = verifyToken(request);
    if (!decoded) {
      return NextResponse.json(
        { error: 'غير مصرح' },
        { status: 401 }
      );
    }

    const conversationId = parseInt(params.id);

    // التحقق من أن المستخدم مشارك في المحادثة
    const participant = await env.DB.prepare(
      'SELECT * FROM conversation_participants WHERE conversation_id = ? AND user_id = ?'
    )
      .bind(conversationId, decoded.id)
      .first();

    if (!participant) {
      return NextResponse.json(
        { error: 'غير مصرح للوصول إلى هذه المحادثة' },
        { status: 403 }
      );
    }

    // جلب الرسائل
    const messages = await env.DB.prepare(`
      SELECT m.*, u.username as sender_name
      FROM messages m
      JOIN users u ON m.sender_id = u.id
      WHERE m.conversation_id = ?
      ORDER BY m.created_at ASC
    `)
      .bind(conversationId)
      .all();

    // تحديث حالة القراءة للرسائل
    await env.DB.prepare(`
      UPDATE messages
      SET is_read = 1
      WHERE conversation_id = ?
      AND sender_id != ?
      AND is_read = 0
    `)
      .bind(conversationId, decoded.id)
      .run();

    // تحديث آخر قراءة للمستخدم
    await env.DB.prepare(`
      UPDATE conversation_participants
      SET last_read_at = CURRENT_TIMESTAMP
      WHERE conversation_id = ?
      AND user_id = ?
    `)
      .bind(conversationId, decoded.id)
      .run();

    return NextResponse.json({
      messages: messages.results
    });
  } catch (error) {
    console.error('خطأ في جلب الرسائل:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في الخادم' },
      { status: 500 }
    );
  }
}

// إرسال رسالة جديدة
export async function POST(
  request: NextRequest,
  { params, env }: { params: { id: string }, env: { DB: D1Database } }
) {
  try {
    // التحقق من المستخدم
    const decoded = verifyToken(request);
    if (!decoded) {
      return NextResponse.json(
        { error: 'غير مصرح' },
        { status: 401 }
      );
    }

    const conversationId = parseInt(params.id);
    const { content } = await request.json();

    if (!content) {
      return NextResponse.json(
        { error: 'محتوى الرسالة مطلوب' },
        { status: 400 }
      );
    }

    // التحقق من أن المستخدم مشارك في المحادثة
    const participant = await env.DB.prepare(
      'SELECT * FROM conversation_participants WHERE conversation_id = ? AND user_id = ?'
    )
      .bind(conversationId, decoded.id)
      .first();

    if (!participant) {
      return NextResponse.json(
        { error: 'غير مصرح للوصول إلى هذه المحادثة' },
        { status: 403 }
      );
    }

    // إرسال الرسالة
    const result = await env.DB.prepare(`
      INSERT INTO messages (conversation_id, sender_id, content)
      VALUES (?, ?, ?)
      RETURNING id, conversation_id, sender_id, content, is_read, created_at
    `)
      .bind(conversationId, decoded.id, content)
      .first();

    if (!result) {
      return NextResponse.json(
        { error: 'فشل في إرسال الرسالة' },
        { status: 500 }
      );
    }

    // تحديث وقت آخر تحديث للمحادثة
    await env.DB.prepare(
      'UPDATE conversations SET updated_at = CURRENT_TIMESTAMP WHERE id = ?'
    )
      .bind(conversationId)
      .run();

    // جلب اسم المرسل
    const user = await env.DB.prepare(
      'SELECT username FROM users WHERE id = ?'
    )
      .bind(decoded.id)
      .first();

    return NextResponse.json({
      message: {
        ...result,
        sender_name: user?.username
      }
    });
  } catch (error) {
    console.error('خطأ في إرسال الرسالة:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في الخادم' },
      { status: 500 }
    );
  }
}
