import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

// المفتاح السري لتوقيع JWT
const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret_key';

// دالة لتسجيل الدخول
export async function POST(request: NextRequest, { env }: { env: { DB: D1Database } }) {
  try {
    const { username, password } = await request.json();

    // التحقق من البيانات المدخلة
    if (!username || !password) {
      return NextResponse.json(
        { error: 'اسم المستخدم وكلمة المرور مطلوبان' },
        { status: 400 }
      );
    }

    // البحث عن المستخدم في قاعدة البيانات
    const user = await env.DB.prepare(
      'SELECT * FROM users WHERE username = ?'
    )
      .bind(username)
      .first();

    if (!user) {
      return NextResponse.json(
        { error: 'اسم المستخدم أو كلمة المرور غير صحيحة' },
        { status: 401 }
      );
    }

    // التحقق من كلمة المرور
    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch) {
      return NextResponse.json(
        { error: 'اسم المستخدم أو كلمة المرور غير صحيحة' },
        { status: 401 }
      );
    }

    // تحديث حالة المستخدم إلى متصل
    await env.DB.prepare(
      'UPDATE users SET status = ?, last_seen = CURRENT_TIMESTAMP WHERE id = ?'
    )
      .bind('online', user.id)
      .run();

    // إنشاء توكن JWT
    const token = jwt.sign(
      { id: user.id, username: user.username, email: user.email },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    // إرجاع بيانات المستخدم والتوكن
    return NextResponse.json({
      message: 'تم تسجيل الدخول بنجاح',
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        full_name: user.full_name,
        profile_picture: user.profile_picture
      },
      token
    });
  } catch (error) {
    console.error('خطأ في تسجيل الدخول:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في الخادم' },
      { status: 500 }
    );
  }
}
