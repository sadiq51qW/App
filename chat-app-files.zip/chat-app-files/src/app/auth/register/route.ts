import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

// المفتاح السري لتوقيع JWT
const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret_key';

// دالة لإنشاء مستخدم جديد
export async function POST(request: NextRequest, { env }: { env: { DB: D1Database } }) {
  try {
    const { username, email, password, full_name } = await request.json();

    // التحقق من البيانات المدخلة
    if (!username || !email || !password || !full_name) {
      return NextResponse.json(
        { error: 'جميع الحقول مطلوبة' },
        { status: 400 }
      );
    }

    // التحقق من عدم وجود مستخدم بنفس اسم المستخدم أو البريد الإلكتروني
    const existingUser = await env.DB.prepare(
      'SELECT * FROM users WHERE username = ? OR email = ?'
    )
      .bind(username, email)
      .first();

    if (existingUser) {
      return NextResponse.json(
        { error: 'اسم المستخدم أو البريد الإلكتروني مستخدم بالفعل' },
        { status: 409 }
      );
    }

    // تشفير كلمة المرور
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // إنشاء المستخدم في قاعدة البيانات
    const result = await env.DB.prepare(
      'INSERT INTO users (username, email, password_hash, full_name, status) VALUES (?, ?, ?, ?, ?) RETURNING id'
    )
      .bind(username, email, hashedPassword, full_name, 'offline')
      .first();

    if (!result) {
      return NextResponse.json(
        { error: 'فشل في إنشاء المستخدم' },
        { status: 500 }
      );
    }

    // إنشاء توكن JWT
    const token = jwt.sign(
      { id: result.id, username, email },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    // إرجاع بيانات المستخدم والتوكن
    return NextResponse.json({
      message: 'تم إنشاء المستخدم بنجاح',
      user: {
        id: result.id,
        username,
        email,
        full_name
      },
      token
    });
  } catch (error) {
    console.error('خطأ في إنشاء المستخدم:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في الخادم' },
      { status: 500 }
    );
  }
}
