import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import jwt from 'jsonwebtoken';

// المفتاح السري لتوقيع JWT
const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret_key';

// دالة للتحقق من صحة التوكن وإرجاع بيانات المستخدم
export async function GET(request: NextRequest, { env }: { env: { DB: D1Database } }) {
  try {
    // استخراج التوكن من رأس الطلب
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        { error: 'غير مصرح' },
        { status: 401 }
      );
    }

    const token = authHeader.split(' ')[1];

    // التحقق من صحة التوكن
    const decoded = jwt.verify(token, JWT_SECRET) as { id: number };
    
    // البحث عن المستخدم في قاعدة البيانات
    const user = await env.DB.prepare(
      'SELECT id, username, email, full_name, profile_picture, status, last_seen FROM users WHERE id = ?'
    )
      .bind(decoded.id)
      .first();

    if (!user) {
      return NextResponse.json(
        { error: 'المستخدم غير موجود' },
        { status: 404 }
      );
    }

    // تحديث آخر ظهور للمستخدم
    await env.DB.prepare(
      'UPDATE users SET last_seen = CURRENT_TIMESTAMP WHERE id = ?'
    )
      .bind(user.id)
      .run();

    // إرجاع بيانات المستخدم
    return NextResponse.json({
      user
    });
  } catch (error) {
    console.error('خطأ في التحقق من المستخدم:', error);
    return NextResponse.json(
      { error: 'غير مصرح' },
      { status: 401 }
    );
  }
}

// دالة لتسجيل الخروج
export async function POST(request: NextRequest, { env }: { env: { DB: D1Database } }) {
  try {
    // استخراج التوكن من رأس الطلب
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        { error: 'غير مصرح' },
        { status: 401 }
      );
    }

    const token = authHeader.split(' ')[1];

    // التحقق من صحة التوكن
    const decoded = jwt.verify(token, JWT_SECRET) as { id: number };
    
    // تحديث حالة المستخدم إلى غير متصل
    await env.DB.prepare(
      'UPDATE users SET status = ?, last_seen = CURRENT_TIMESTAMP WHERE id = ?'
    )
      .bind('offline', decoded.id)
      .run();

    return NextResponse.json({
      message: 'تم تسجيل الخروج بنجاح'
    });
  } catch (error) {
    console.error('خطأ في تسجيل الخروج:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في الخادم' },
      { status: 500 }
    );
  }
}
