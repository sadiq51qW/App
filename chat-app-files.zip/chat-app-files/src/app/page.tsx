'use client';

import { useEffect, useState } from 'react';
import ProtectedRoute from '@/components/auth/ProtectedRoute';

export default function HomePage() {
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    // استرجاع بيانات المستخدم من التخزين المحلي
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  return (
    <ProtectedRoute>
      <div className="flex min-h-screen flex-col bg-gray-100">
        <header className="bg-white p-4 shadow">
          <div className="container mx-auto flex items-center justify-between">
            <h1 className="text-xl font-bold text-blue-600">تطبيق المراسلة</h1>
            {user && (
              <div className="flex items-center space-x-4 space-x-reverse">
                <span className="text-gray-700">مرحباً، {user.full_name}</span>
                <button
                  onClick={async () => {
                    const token = localStorage.getItem('token');
                    if (token) {
                      try {
                        await fetch('/auth/me', {
                          method: 'POST',
                          headers: {
                            Authorization: `Bearer ${token}`,
                          },
                        });
                      } catch (error) {
                        console.error('خطأ في تسجيل الخروج:', error);
                      }
                    }
                    localStorage.removeItem('token');
                    localStorage.removeItem('user');
                    window.location.href = '/login';
                  }}
                  className="rounded bg-red-500 px-4 py-2 text-white hover:bg-red-600"
                >
                  تسجيل الخروج
                </button>
              </div>
            )}
          </div>
        </header>
        
        <main className="container mx-auto flex-1 p-4">
          <div className="rounded-lg bg-white p-6 shadow">
            <h2 className="mb-4 text-2xl font-bold text-gray-800">مرحباً بك في تطبيق المراسلة</h2>
            <p className="text-gray-600">
              تم تسجيل دخولك بنجاح. قريباً ستتمكن من استخدام ميزات المراسلة للتواصل مع أصدقائك وعائلتك.
            </p>
          </div>
        </main>
        
        <footer className="bg-gray-800 p-4 text-center text-white">
          <p>&copy; 2025 تطبيق المراسلة - جميع الحقوق محفوظة</p>
        </footer>
      </div>
    </ProtectedRoute>
  );
}
