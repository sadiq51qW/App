'use client';

import { useState, useEffect } from 'react';
import ProtectedRoute from '@/components/auth/ProtectedRoute';
import ContactsList from '@/components/chat/ContactsList';
import ChatWindow from '@/components/chat/ChatWindow';

interface Contact {
  id: number;
  username: string;
  full_name: string;
  profile_picture?: string;
  status: string;
  last_seen?: string;
}

interface Conversation {
  id: number;
  name: string;
  type: 'private' | 'group';
  last_message?: string;
  last_message_time?: string;
  unread_count: number;
}

export default function ChatPage() {
  const [user, setUser] = useState<any>(null);
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [currentConversationId, setCurrentConversationId] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    // استرجاع بيانات المستخدم من التخزين المحلي
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }

    // جلب المحادثات
    const fetchConversations = async () => {
      try {
        const token = localStorage.getItem('token');
        if (!token) return;

        const response = await fetch('/api/conversations', {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        if (!response.ok) {
          throw new Error('فشل في جلب المحادثات');
        }

        const data = await response.json();
        setConversations(data.conversations);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchConversations();
  }, []);

  const handleSelectContact = async (contact: Contact) => {
    setSelectedContact(contact);
    
    // البحث عن محادثة موجودة مع جهة الاتصال
    const existingConversation = conversations.find(conv => 
      conv.type === 'private' && conv.name === contact.full_name
    );

    if (existingConversation) {
      setCurrentConversationId(existingConversation.id);
    } else {
      // إنشاء محادثة جديدة
      try {
        const token = localStorage.getItem('token');
        if (!token) return;

        const response = await fetch('/api/conversations', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            contact_id: contact.id,
            type: 'private'
          }),
        });

        if (!response.ok) {
          throw new Error('فشل في إنشاء المحادثة');
        }

        const data = await response.json();
        setCurrentConversationId(data.conversation_id);
        
        // تحديث قائمة المحادثات
        const newConversation: Conversation = {
          id: data.conversation_id,
          name: contact.full_name,
          type: 'private',
          unread_count: 0
        };
        
        setConversations(prev => [newConversation, ...prev]);
      } catch (err: any) {
        setError(err.message);
      }
    }
  };

  return (
    <ProtectedRoute>
      <div className="flex h-screen flex-col">
        <header className="border-b border-gray-200 bg-white p-4 shadow-sm">
          <div className="container mx-auto flex items-center justify-between">
            <h1 className="text-xl font-bold text-blue-600">تطبيق المراسلة</h1>
            {user && (
              <div className="flex items-center space-x-4 space-x-reverse">
                <span className="text-gray-700">مرحباً، {user.full_name}</span>
                <button
                  onClick={async () => {
                    const token = localStorage.getItem('token');
                    if (token) {
                      try {
                        await fetch('/auth/me', {
                          method: 'POST',
                          headers: {
                            Authorization: `Bearer ${token}`,
                          },
                        });
                      } catch (error) {
                        console.error('خطأ في تسجيل الخروج:', error);
                      }
                    }
                    localStorage.removeItem('token');
                    localStorage.removeItem('user');
                    window.location.href = '/login';
                  }}
                  className="rounded bg-red-500 px-4 py-2 text-white hover:bg-red-600"
                >
                  تسجيل الخروج
                </button>
              </div>
            )}
          </div>
        </header>
        
        <main className="flex-1 overflow-hidden">
          <div className="flex h-full">
            {/* قائمة جهات الاتصال */}
            <div className="w-1/3 border-l border-gray-200 bg-white">
              <ContactsList onSelectContact={handleSelectContact} />
            </div>
            
            {/* نافذة المحادثة */}
            <div className="w-2/3">
              <ChatWindow 
                conversationId={currentConversationId} 
                currentUserId={user?.id} 
                contactName={selectedContact?.full_name || ''} 
              />
            </div>
          </div>
        </main>
      </div>
    </ProtectedRoute>
  );
}
