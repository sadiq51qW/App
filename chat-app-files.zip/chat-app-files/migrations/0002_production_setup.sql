-- ملف ترحيل قاعدة البيانات للإنتاج
-- Migration number: 0002_production_setup 2025-04-08

-- إنشاء فهارس إضافية لتحسين الأداء
CREATE INDEX IF NOT EXISTS idx_messages_is_read ON messages(is_read);
CREATE INDEX IF NOT EXISTS idx_users_status ON users(status);
CREATE INDEX IF NOT EXISTS idx_conversation_participants_last_read_at ON conversation_participants(last_read_at);

-- إضافة قيود للتحقق من صحة البيانات
ALTER TABLE users ADD CONSTRAINT check_email_format CHECK (email LIKE '%@%.%');
ALTER TABLE messages ADD CONSTRAINT check_content_not_empty CHECK (content != '');

-- إعداد حسابات النظام
INSERT OR IGNORE INTO users (username, email, password_hash, full_name, status, created_at, updated_at)
VALUES 
  ('system', 'system@chatapp.com', '$2a$10$XgXLGQbMdmG5xYjdJVG4XeZD.9JGLGvHgQfP9r5uxMOGIiTGwRE2e', 'نظام', 'online', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

-- إنشاء جدول للإحصائيات
CREATE TABLE IF NOT EXISTS statistics (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT UNIQUE NOT NULL,
  value INTEGER NOT NULL DEFAULT 0,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- إدخال بيانات أولية للإحصائيات
INSERT OR IGNORE INTO statistics (name, value) VALUES 
  ('total_users', 0),
  ('total_messages', 0),
  ('active_conversations', 0);

-- إنشاء مشغلات (triggers) لتحديث الإحصائيات
-- مشغل لتحديث إجمالي المستخدمين
CREATE TRIGGER IF NOT EXISTS update_total_users_insert
AFTER INSERT ON users
BEGIN
  UPDATE statistics SET value = value + 1, updated_at = CURRENT_TIMESTAMP WHERE name = 'total_users';
END;

-- مشغل لتحديث إجمالي الرسائل
CREATE TRIGGER IF NOT EXISTS update_total_messages_insert
AFTER INSERT ON messages
BEGIN
  UPDATE statistics SET value = value + 1, updated_at = CURRENT_TIMESTAMP WHERE name = 'total_messages';
END;

-- مشغل لتحديث المحادثات النشطة
CREATE TRIGGER IF NOT EXISTS update_active_conversations_insert
AFTER INSERT ON conversations
BEGIN
  UPDATE statistics SET value = value + 1, updated_at = CURRENT_TIMESTAMP WHERE name = 'active_conversations';
END;

-- مشغل لتحديث المحادثات النشطة عند الحذف
CREATE TRIGGER IF NOT EXISTS update_active_conversations_delete
AFTER DELETE ON conversations
BEGIN
  UPDATE statistics SET value = value - 1, updated_at = CURRENT_TIMESTAMP WHERE name = 'active_conversations';
END;
